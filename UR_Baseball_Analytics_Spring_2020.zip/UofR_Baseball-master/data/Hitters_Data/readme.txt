The above .csv files contain average statistics from 2017-2020 for the Liberty League conference 
and the overall NCAA for college baseball. In addition, the prediction data table is also 
included in this repository. 
